# Employee-Management-System
Employee Management System is a Java application, developed to maintain the details of employees working in any organization. It maintains information about the personal details of their employees. The application is completed developed using Java Language and using MySql Database.  This application is helpful to the department of the organization which maintains data of employees related to an organization   


OBJECTIVE OF THE PROJECT 
------------------------ 

In this world of growing technologies, everything has been computerized. With a large number of work opportunities, the Human workforce has increased. Thus there is a need for a system that can handle the data of such a large number of employees in an organization. This project simplifies the task of maintaining records because of its user-friendly nature.  

Features: 
1. Login  
2. Add a new employee details 
3. Remove the details of an employee. 
4. Update the details of an employee. 
5. Print the details of an employee, etc.
